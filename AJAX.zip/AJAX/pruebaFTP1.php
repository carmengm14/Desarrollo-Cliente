<html>
<head>
</head>
<body>
    <h1>Escribe aquí tu nombre</h1>
<?php echo "prueba de FTP 1"; ?>
</body>
</html>

